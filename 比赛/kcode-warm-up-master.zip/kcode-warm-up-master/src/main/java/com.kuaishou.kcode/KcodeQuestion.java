package com.kuaishou.kcode;

import java.io.InputStream;

/**
 * @author kcode
 * Created on 2020-05-20
 */
public class KcodeQuestion {

    /**
     * prepare() 方法用来接受输入数据集，数据集格式参考README.md
     *
     * @param inputStream
     */
    public void prepare(InputStream inputStream) {
    }

    /**
     * getResult() 方法是由kcode评测系统调用，是评测程序正确性的一部分，请按照题目要求返回正确数据
     * 输入格式和输出格式参考 README.md
     *
     * @param timestamp 秒级时间戳
     * @param methodName 方法名称
     */
    public String getResult(Long timestamp, String methodName) {
        // do something
        return "QPS,P99,P50,AVG,MAX";
    }
}
